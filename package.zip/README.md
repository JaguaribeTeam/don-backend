### Links Importantes:
 - https://www.prisma.io/docs/getting-started/quickstart
 - https://www.npmjs.com/package/dotenv
 - https://www.npmjs.com/package/aws-sdk
 - 