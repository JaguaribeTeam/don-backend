/**
 * @note
 * @author Alysson Araújo
 * @updateDate 19/10/2022
 *
 * Será preciso entrar a autenticação do usuário via token para que
 * dá mais segurança e veracidade para quem está modificando os dados
 */

export class UsuarioUserCase {

}